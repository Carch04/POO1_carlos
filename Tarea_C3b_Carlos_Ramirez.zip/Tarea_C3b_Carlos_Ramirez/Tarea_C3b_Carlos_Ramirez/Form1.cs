﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tarea_C3b_Carlos_Ramirez
{
    public partial class Form1 : Form
    {
        int contador = 0;

        public Form1()
        {
            InitializeComponent();

            label2.Text = "";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();

            double a = Convert.ToDouble(textBox1.Text);

            Random rnd = new Random();

            for (int i = 0; i < a; i++)
            {
                int n = rnd.Next(101);

                listBox1.Items.Add(n);

            }

            for (int i = 0; i < a; i++)
            {
                if (Convert.ToInt32(listBox1.Items[i]) > 20)
                {
                    contador = contador + 1;
                }
            }

            double porcentaje = (contador / a) * 100;

            decimal porcdecimal = Convert.ToDecimal(porcentaje);
            porcdecimal = decimal.Round(Convert.ToDecimal(porcentaje), 2);

            label2.Text = "El porcentaje de numeros mayores a 20 es del " + porcdecimal + "%";

            contador = 0;
            a = 0;
        }
    }
}
