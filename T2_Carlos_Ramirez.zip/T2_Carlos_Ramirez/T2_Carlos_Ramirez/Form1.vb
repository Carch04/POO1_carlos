﻿Imports System.Math

Public Class Form1
    Dim contProd As Integer = 0
    Dim acumKg As Double = 0
    Dim promKg As Double = 0
    Dim prodMayor As Integer = 0
    Dim porcProd As Double = 0
    Dim pesoKg As Double = 0
    Dim code As String = ""

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Label3.Text = ""
        Label4.Text = ""

        PictureBox1.Load(Application.StartupPath & "/img/p1.jpg")
        PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage

        PictureBox2.Load(Application.StartupPath & "/img/p2.jpg")
        PictureBox2.SizeMode = PictureBoxSizeMode.StretchImage
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        code = TextBox1.Text
        pesoKg = Val(TextBox2.Text)
        Dim pesog As Double = pesoKg * 1000

        acumKg = acumKg + pesoKg

        If code <> "" And pesoKg > 0 Then

            contProd = contProd + 1

            ListBox1.Items.Add(code & " pesa " & pesoKg & " kg, que es igual a " & pesog & "g.")
            Button2.Enabled = True
            Button1.Enabled = False

        End If

        'MsgBox(contProd)'

        promKg = acumKg / contProd

        If pesoKg > 2 Then
            prodMayor = prodMayor + 1
        End If

        porcProd = (prodMayor / contProd) * 100




    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Button1.Enabled = True

        Label3.Text = "Promedio de kgs: " & Math.Round(promKg, 2) & "kg."
        Label4.Text = "Porcentaje de productos con peso superior a 2 kgs: " & Math.Round(porcProd, 2) & "%"

        TextBox1.Clear()
        TextBox2.Clear()

        If pesoKg > 2 Then
            ListBox2.Items.Add(code & " tiene un peso mayor a 2 Kg.")
        End If


        Button2.Enabled = False

        PictureBox3.Load(Application.StartupPath & "/img/p2.jpg")
        PictureBox3.SizeMode = PictureBoxSizeMode.StretchImage

        PictureBox4.Load(Application.StartupPath & "/img/p1.jpg")
        PictureBox4.SizeMode = PictureBoxSizeMode.StretchImage



    End Sub
End Class
